import os,re,json,sqlite3,time,random,math,csv,sys
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.preprocessing import StandardScaler,OneHotEncoder
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score,confusion_matrix,precision_score,recall_score,f1_score,accuracy_score
from sklearn.decomposition import PCA
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.base import clone
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import joblib,mock_llm
ROOT=Path('.'); (ROOT/'outputs').mkdir(exist_ok=True); (ROOT/'state').mkdir(exist_ok=True); (ROOT/'data/clean').mkdir(parents=True,exist_ok=True); (ROOT/'sql').mkdir(exist_ok=True)
def part_a():
 c=pd.read_csv('data/raw/customers.csv',keep_default_na=False); p=pd.read_csv('data/raw/products.csv'); o=pd.read_csv('data/raw/orders.csv',keep_default_na=False)
 c['city']=c.city.astype(str).str.strip().str.title(); c['gender']=c.gender.astype(str).str.strip().str.lower().map({'male':'male','m':'male','female':'female','f':'female'}).fillna('unknown'); c['age']=pd.to_numeric(c.age,errors='coerce'); c.loc[~c.age.between(10,100),'age']=np.nan; c['age']=c.age.fillna(c.groupby('city').age.transform('median')); c['signup_date']=pd.to_datetime(c.signup_date).dt.strftime('%Y-%m-%d')
 o['order_ts']=pd.to_datetime(o.order_ts); o=o.drop_duplicates(); o=o.sort_values('order_ts').drop_duplicates('order_id',keep='last'); o['quantity']=pd.to_numeric(o.quantity); o['discount_pct']=pd.to_numeric(o.discount_pct); o['order_amount']=pd.to_numeric(o.order_amount,errors='coerce'); o=o.merge(p[['product_id','price_inr','category']],on='product_id',how='left'); mask=o.order_amount.isna(); o.loc[mask,'order_amount']=(o.loc[mask,'price_inr']*o.loc[mask,'quantity']*(1-o.loc[mask,'discount_pct']/100)).round(2); o['delivery_minutes']=pd.to_numeric(o.delivery_minutes,errors='coerce'); o.loc[o.delivery_minutes<0,'delivery_minutes']=np.nan; o.loc[o.status=='cancelled','delivery_minutes']=np.nan; med=o.loc[(o.status=='completed')&o.delivery_minutes.notna()].groupby('category').delivery_minutes.transform('median'); # category-specific median lookup
 catmed=o.loc[(o.status=='completed')&o.delivery_minutes.notna()].groupby('category').delivery_minutes.median(); cm=(o.status=='completed')&o.delivery_minutes.isna(); o.loc[cm,'delivery_minutes']=o.loc[cm,'category'].map(catmed)
 o=o.drop(columns=['price_inr','category']); o['order_ts']=o.order_ts.dt.strftime('%Y-%m-%d %H:%M:%S');
 for name,df in [('customers',c),('products',p),('orders',o)]:df.to_csv(f'data/clean/{name}.csv',index=False)
 with sqlite3.connect('data/instamart.db') as con:
  for name,df in [('customers',c),('products',p),('orders',o)]:df.to_sql(name,con,if_exists='replace',index=False)
 # validation checkpoints
 assert len(c)==1200 and c.city.nunique()==6 and c.age.isna().sum()==0
 assert len(o)==12309 and (o.status=='completed').sum()==11110 and (o.status=='cancelled').sum()==1199
 assert o.loc[o.status=='completed','delivery_minutes'].isna().sum()==0 and o.loc[o.status=='cancelled','delivery_minutes'].isna().sum()==1199
 assert round(o.loc[o.status=='completed','order_amount'].sum(),2)==2998668.80
 print('ALL CHECKPOINTS PASSED')
 q='''-- Q1
SELECT customer_id, SUM(order_amount) total FROM orders WHERE status='completed' AND order_amount>500 GROUP BY customer_id HAVING SUM(order_amount)>8000;
-- Q2
SELECT c.city,p.category,SUM(o.order_amount) revenue FROM orders o JOIN customers c USING(customer_id) JOIN products p USING(product_id) WHERE o.status='completed' GROUP BY c.city,p.category;
-- Q3
SELECT * FROM products WHERE price_inr>(SELECT AVG(price_inr) FROM products);
-- Q4
SELECT c.customer_id FROM customers c LEFT JOIN orders o ON c.customer_id=o.customer_id AND o.status='completed' WHERE o.order_id IS NULL;
-- Q5
WITH totals AS (SELECT customer_id,SUM(order_amount) spend FROM orders WHERE status='completed' GROUP BY customer_id), av AS (SELECT AVG(spend) avg_spend FROM totals) SELECT * FROM totals,av WHERE spend>avg_spend;
-- Q6
WITH spend AS (SELECT c.customer_id,c.city,SUM(o.order_amount) total_spend FROM customers c JOIN orders o USING(customer_id) WHERE o.status='completed' GROUP BY c.customer_id,c.city) SELECT *,RANK() OVER(PARTITION BY city ORDER BY total_spend DESC) rnk,DENSE_RANK() OVER(PARTITION BY city ORDER BY total_spend DESC) dense_rnk,ROW_NUMBER() OVER(PARTITION BY city ORDER BY total_spend DESC) row_num FROM spend;
-- Q7
WITH daily AS (SELECT substr(order_ts,1,10) day,SUM(order_amount) revenue FROM orders WHERE status='completed' GROUP BY substr(order_ts,1,10)) SELECT day,revenue,SUM(revenue) OVER(ORDER BY day) cumulative_revenue FROM daily;'''
 Path('sql/queries.sql').write_text(q)
 # save query execution summaries
 with sqlite3.connect('data/instamart.db') as con:
  summaries=[]
  for i,stmt in enumerate([x.strip() for x in q.split(';') if x.strip()],1):
   stmt='\n'.join(z for z in stmt.splitlines() if not z.strip().startswith('--'))
   try: d=pd.read_sql_query(stmt,con); summaries.append({'query':i,'rows':len(d),'sample':d.head(3).to_dict('records')})
   except Exception as e:summaries.append({'query':i,'error':str(e)})
 Path('outputs/sql_summaries.json').write_text(json.dumps(summaries,indent=2,default=str))
 return c,p,o

def part_b(c,p,o):
 o['order_ts']=pd.to_datetime(o.order_ts); done=o[o.status=='completed'].copy(); snap=pd.Timestamp('2025-10-01'); rfm=done.groupby('customer_id').agg(last=('order_ts','max'),frequency=('order_id','nunique'),monetary=('order_amount','sum')).reset_index(); rfm['recency']=(snap-rfm['last']).dt.days; rfm=rfm[['customer_id','recency','frequency','monetary']]
 X=rfm[['recency','frequency','monetary']]; scaler=StandardScaler(); Xs=scaler.fit_transform(X); km_rows=[]
 for k in range(2,9):
  km=KMeans(n_clusters=k,n_init=10,random_state=42).fit(Xs); km_rows.append({'K':k,'inertia':km.inertia_,'silhouette':silhouette_score(Xs,km.labels_)})
 pd.DataFrame(km_rows).to_csv('outputs/kmeans_metrics.csv',index=False); K=4; km=KMeans(n_clusters=K,n_init=10,random_state=42); rfm['segment_id']=km.fit_predict(Xs); prof=rfm.groupby('segment_id').agg(size=('customer_id','size'),mean_recency=('recency','mean'),mean_frequency=('frequency','mean'),mean_monetary=('monetary','mean')).reset_index(); premium=int(prof.loc[prof.mean_monetary.idxmax(),'segment_id']); names={}
 for _,row in prof.iterrows():
  sid=int(row.segment_id); names[sid]=('Premium' if sid==premium else 'Frequent Essentials' if row.mean_frequency>=12 else 'Dormant / At-Risk' if row.mean_recency>=60 else 'High Basket Occasional' if row.mean_monetary>3000 else 'Occasional Value')
 rfm['segment_name']=rfm.segment_id.map(names); rfm['is_premium']=rfm.segment_id==premium; rfm.to_csv('outputs/customer_segments.csv',index=False); prof.to_csv('outputs/segment_profile.csv',index=False); pca=PCA(n_components=2).fit(Xs); Path('outputs/pca.json').write_text(json.dumps({'explained_variance_ratio':pca.explained_variance_ratio_.tolist()},indent=2))
 # Lapse cohort and leakage-safe features: all feature orders strictly before cutoff.
 cutoff=pd.Timestamp('2025-09-01'); pre=o[o.order_ts<cutoff].copy(); pre_done=pre[pre.status=='completed']; cohort=pre_done.customer_id.unique(); after=done[(done.order_ts>=cutoff)&(done.order_ts<pd.Timestamp('2025-10-01'))]; lapsed=set(cohort)-set(after.customer_id); f=pre_done.groupby('customer_id').agg(last=('order_ts','max'),frequency=('order_id','nunique'),monetary=('order_amount','sum'),avg_discount=('discount_pct','mean'),avg_delivery=('delivery_minutes','mean')).reset_index(); f['recency']=(cutoff-f['last']).dt.days; canc=pre.groupby('customer_id').status.apply(lambda x:(x=='cancelled').sum()/max(1,x.isin(['completed','cancelled']).sum())).rename('cancellation_rate'); fav=pre_done.merge(p[['product_id','category']],on='product_id').groupby('customer_id').category.agg(lambda x:x.mode().iloc[0]).rename('favorite_category'); f=f.merge(canc,on='customer_id').merge(fav,on='customer_id').merge(c[['customer_id','city','age','gender','signup_date']],on='customer_id'); f['tenure_days']=(cutoff-pd.to_datetime(f.signup_date)).dt.days; f['lapsed']=f.customer_id.isin(lapsed).astype(int); f=f.drop(columns=['last','signup_date']); num=['recency','frequency','monetary','avg_discount','cancellation_rate','avg_delivery','age','tenure_days']; cat=['favorite_category','city','gender']; f[num]=f[num].fillna(f[num].median()); f[cat]=f[cat].fillna('unknown'); X=f[num+cat]; assert not X.isna().any().any(), 'feature matrix contains missing values'; y=f.lapsed; Xtr,Xte,ytr,yte,idxtr,idxte=train_test_split(X,y,f.index,test_size=.2,stratify=y,random_state=42)
 preproc=ColumnTransformer([('num',Pipeline([('imputer',SimpleImputer(strategy='median')),('scaler',StandardScaler())]),num),('cat',OneHotEncoder(drop='first',handle_unknown='ignore'),cat)])
 lr=Pipeline([('prep',preproc),('model',LogisticRegression(max_iter=1000))]); gs_lr=GridSearchCV(lr,{'model__C':[.01,.1,1,10,100]},cv=5,scoring='f1'); gs_lr.fit(Xtr,ytr)
 rf=Pipeline([('prep',preproc),('model',RandomForestClassifier(n_estimators=100,random_state=42))]); gs_rf=GridSearchCV(rf,{'model__max_depth':[3,5,8],'model__min_samples_leaf':[5,10,20]},cv=5,scoring='f1'); gs_rf.fit(Xtr,ytr)
 chosen=gs_rf.best_estimator_; pred=chosen.predict(Xte); f1=f1_score(yte,pred,zero_division=0); joblib.dump(chosen,'outputs/lapse_model.joblib'); reloaded=joblib.load('outputs/lapse_model.joblib'); assert np.array_equal(pred,reloaded.predict(Xte))
 # retention list uses post-hoc segment label, clearly documented.
 te=f.loc[idxte,['customer_id','lapsed']].copy(); te['prob']=chosen.predict_proba(Xte)[:,1]; premium_ids=set(rfm.loc[rfm.is_premium,'customer_id']); ret=te[te.customer_id.isin(premium_ids)].sort_values('prob',ascending=False).head(10); ret.rename(columns={'prob':'lapse_probability','lapsed':'actually_lapsed'})[['customer_id','lapse_probability','actually_lapsed']].to_csv('outputs/retention_list.csv',index=False)
 # Interpretation and training-only minority oversampling experiment.
 rf_model=chosen.named_steps['model']; feature_names=chosen.named_steps['prep'].get_feature_names_out(); importances=sorted([{'feature':str(n),'importance':float(v)} for n,v in zip(feature_names,rf_model.feature_importances_)],key=lambda z:z['importance'],reverse=True)[:5]
 lrbest=gs_lr.best_estimator_; joblib.dump(lrbest,'outputs/lapse_logistic_model.joblib'); lrnames=lrbest.named_steps['prep'].get_feature_names_out(); coef=lrbest.named_steps['model'].coef_[0]; coeffs=sorted([{'feature':str(n),'coefficient':float(v),'sign':'positive' if v>0 else 'negative'} for n,v in zip(lrnames,coef)],key=lambda z:abs(z['coefficient']),reverse=True)[:10]
 # Duplicate lapsed training rows only until class counts are equal; never resample test rows.
 rng=np.random.RandomState(42); counts=ytr.value_counts(); maj=int(counts.max()); pieces=[Xtr.copy()]; labels=[ytr.copy()]
 for cls in sorted(counts.index):
  need=maj-int(counts[cls])
  if need>0:
   ids=ytr[ytr==cls].index.to_numpy(); sampled=rng.choice(ids,size=need,replace=True); pieces.append(Xtr.loc[sampled]); labels.append(ytr.loc[sampled])
 Xbal=pd.concat(pieces); ybal=pd.concat(labels); lr_bal=clone(gs_lr.best_estimator_); lr_bal.fit(Xbal,ybal); pb=lr_bal.predict(Xte)
 interpretation={'rf_top5_importances':importances,'logistic_largest_coefficients':coeffs,'frequency_scaler_training_mean':float(gs_lr.best_estimator_.named_steps['prep'].named_transformers_['num'].named_steps['scaler'].mean_[1]),'full_cohort_frequency_mean':float(f.frequency.mean()),'oversampled_counts':{str(k):int(v) for k,v in ybal.value_counts().items()},'logistic_original_test':{'precision':precision_score(yte,gs_lr.predict(Xte),zero_division=0),'recall':recall_score(yte,gs_lr.predict(Xte),zero_division=0),'f1':f1_score(yte,gs_lr.predict(Xte),zero_division=0)},'logistic_balanced_test':{'precision':precision_score(yte,pb,zero_division=0),'recall':recall_score(yte,pb,zero_division=0),'f1':f1_score(yte,pb,zero_division=0)}}
 Path('outputs/model_interpretation.json').write_text(json.dumps(interpretation,indent=2,default=str))
 metrics={'cohort_rows':len(f),'lapsed_count':int(y.sum()),'train_rows':len(Xtr),'test_rows':len(Xte),'baseline_accuracy':float((yte==0).mean()),'baseline_lapsed_f1':0,'logistic_best_params':gs_lr.best_params_,'logistic_cv_f1':gs_lr.best_score_,'logistic_test_f1':f1_score(yte,gs_lr.predict(Xte),zero_division=0),'rf_best_params':gs_rf.best_params_,'rf_cv_f1':gs_rf.best_score_,'rf_test_f1':f1,'rf_confusion_matrix':confusion_matrix(yte,pred).tolist(),'rf_precision':precision_score(yte,pred,zero_division=0),'rf_recall':recall_score(yte,pred,zero_division=0),'rf_f1':f1,'retention_true_lapsed':int(ret.lapsed.sum()) if 'lapsed' in ret else int(ret.actually_lapsed.sum()),'rfm_customers':len(rfm),'rfm_recency_median':float(rfm.recency.median()),'pca_variance':pca.explained_variance_ratio_.tolist()}
 Path('outputs/lapse_metrics.json').write_text(json.dumps(metrics,indent=2,default=str)); return rfm

def redact(s):
 counts={}
 for name,pat,repl in [('email',r'[\w.+-]+@[\w-]+\.[\w.]+','[EMAIL]'),('phone',r'\b[6-9]\d{9}\b','[PHONE]'),('order_id',r'ORD-\d{6}','[ORDER_ID]')]:s,n=re.subn(pat,repl,s);counts[name]=n
 return s,counts
def triage(prompt_kind,budget,segments,outfile):
 tickets=pd.read_csv('data/raw/tickets.csv',keep_default_na=False); seg=segments.set_index('customer_id').to_dict('index'); mock_llm.reset(); random.seed(42); total=0; results=[]; counts={'email':0,'phone':0,'order_id':0}; log_name=('few_shot' if prompt_kind=='few' else 'zero_shot' if budget>=100000 else 'budget_demo'); log_path=Path('outputs/retry_log_'+log_name+'.txt'); log_path.write_text(''); prompt=('CLASSIFY You classify support tickets. Allowed categories: billing, delivery, technical, fraud. Reply JSON only: {"category":"...","reason":"..."}.' if prompt_kind=='zero' else 'CLASSIFY You classify support tickets. Allowed categories: billing, delivery, technical, fraud. Reply JSON only: {"category":"...","reason":"..."}.\nEXAMPLES:\nFraud: unauthorized transaction -> {"category":"fraud","reason":"unauthorized"}\nDelivery: package is late -> {"category":"delivery","reason":"late"}')
 for _,r in tickets.iterrows():
  raw=r.text; clean,cc=redact(raw)
  for k,v in cc.items():counts[k]+=v
  assert not re.search(r'[\w.+-]+@[\w-]+\.[\w.]+|\b[6-9]\d{9}\b|ORD-\d{6}',clean)
  status=''; cat=''; used=0
  if not raw.strip():status='skipped_empty'
  elif mock_llm.est_tokens(raw)>400:status='flagged_long'
  elif total>=budget:status='budget_exhausted'
  else:
   msgs=[{'role':'system','content':prompt},{'role':'user','content':clean}]
   for retry_no in range(4):
    try:
     resp=mock_llm.chat(msgs)
     break
    except mock_llm.TransientLLMError:
     if retry_no == 3:
      raise
     wait=.05*(2**retry_no)*random.uniform(.9,1.15)
     log_line=f"retry {r.ticket_id} number {retry_no} wait {wait:.4f}s"
     print(log_line)
     with open('outputs/retry_log.txt','a',encoding='utf-8') as log_file:
      log_file.write(log_line+'\n')
     with log_path.open('a',encoding='utf-8') as run_log:
      run_log.write(log_line+'\n')
     time.sleep(wait)
   used=resp.usage.total_tokens;total+=used; content=resp.choices[0].message.content
   try:
    obj=json.loads(content); cat=obj.get('category','')
    if cat in ['billing','delivery','technical','fraud']:status='classified_json'
    else:status='flagged_invalid_output';cat=''
   except Exception:
    words=re.findall(r'[a-z]+',content.lower()); found=[x for x in ['billing','delivery','technical','fraud'] if x in words]
    if len(found)==1:cat=found[0];status='classified_keyword'
    else:status='flagged_invalid_output';cat=''
  classified=status in ('classified_json','classified_keyword'); route='human_review';priority='NORMAL'; sid=seg.get(r.customer_id,{}); sname=sid.get('segment_name','')
  if classified:
   if cat=='fraud':route='security_team';priority='HIGH'
   elif sid.get('is_premium',False):route='premium_desk';priority='HIGH'
   else:route='support_queue'
  results.append({'ticket_id':r.ticket_id,'customer_id':r.customer_id,'status':status,'category':cat,'segment_name':sname,'priority':priority,'route':route,'tokens_used':used,'true_category':r.true_category})
 df=pd.DataFrame(results); outdf=df;
 if outfile.endswith('triage_results.csv') or outfile.endswith('triage_budget_demo.csv'): outdf=df[['ticket_id','customer_id','status','category','segment_name','priority','route','tokens_used']]
 outdf.to_csv(outfile,index=False);return df,total,counts

def part_d():
 docs=[]
 for path in sorted(Path('data/policies').glob('*.txt')):
  words=path.read_text().split(); start=0
  while start<len(words):
   chunk=words[start:start+40];docs.append({'source':path.name,'text':' '.join(chunk)}); 
   if start+40>=len(words):break
   start+=30
 vec=TfidfVectorizer(); mat=vec.fit_transform([d['text'] for d in docs])
 def retrieve(q,k=3):
  sims=cosine_similarity(vec.transform([q]),mat).ravel(); ids=np.argsort(-sims)[:k];return [{'source':docs[i]['source'],'score':float(sims[i]),'text':docs[i]['text']} for i in ids]
 def answer(q):
  rs=retrieve(q,3); context='\n'.join('['+x['source']+'] '+x['text'] for x in rs); msgs=[{'role':'system','content':'POLICY ASSISTANT. Answer only from supplied context. If missing, say you could not find the information.'},{'role':'user','content':f'CONTEXT:\n{context}\nQUESTION:\n{q}'}]; resp=mock_llm.chat(msgs);return resp.choices[0].message.content,[x['source'] for x in rs]
 evaldf=pd.read_csv('data/raw/policy_eval.csv',keep_default_na=False); ev=[]
 for _,r in evaldf.iterrows():
  rs=retrieve(r.question,3); a,_=answer(r.question); ev.append({'question':r.question,'expected_doc':r.expected_doc,'top3_doc_hit':r.expected_doc=='NONE' or r.expected_doc in [x['source'] for x in rs],'expected_fact_hit':not r.expected_fact or r.expected_fact in a,'answer':a})
 pd.DataFrame(ev).to_csv('outputs/policy_eval_results.csv',index=False);Path('outputs/policy_chunks.json').write_text(json.dumps(docs,indent=2))
 # Repeat evaluation with zero overlap to expose boundary-sensitive retrieval.
 docs0=[]
 for path in sorted(Path('data/policies').glob('*.txt')):
  words=path.read_text().split()
  for start in range(0,len(words),40):
   docs0.append({'source':path.name,'text':' '.join(words[start:start+40])})
 vec0=TfidfVectorizer(); mat0=vec0.fit_transform([d['text'] for d in docs0])
 def retrieve0(q,k=3):
  sims=cosine_similarity(vec0.transform([q]),mat0).ravel(); ids=np.argsort(-sims)[:k]; return [{'source':docs0[i]['source'],'score':float(sims[i]),'text':docs0[i]['text']} for i in ids]
 ev0=[]
 for _,r in evaldf.iterrows():
  rs=retrieve0(r.question,3); context='\n'.join('['+x['source']+'] '+x['text'] for x in rs); resp=mock_llm.chat([{'role':'system','content':'POLICY ASSISTANT. Answer only from supplied context; otherwise say I could not find the information.'},{'role':'user','content':f'CONTEXT:\n{context}\nQUESTION:\n{r.question}'}]); ans=resp.choices[0].message.content; ev0.append({'question':r.question,'expected_doc':r.expected_doc,'top3_doc_hit':r.expected_doc=='NONE' or r.expected_doc in [x['source'] for x in rs],'expected_fact_hit':not r.expected_fact or r.expected_fact in ans,'answer':ans})
 pd.DataFrame(ev0).to_csv('outputs/policy_eval_zero_overlap.csv',index=False)
 # tools and agent
 ledger=Path('outputs/refund_ledger.jsonl');ledger.write_text('')
 def get_order(order_id):
  with sqlite3.connect('data/instamart.db') as con: d=pd.read_sql_query('select order_id,status,order_amount,delivery_minutes from orders where order_id=?',con,params=(order_id,))
  if d.empty:return {'error':'order not found'}
  z=d.iloc[0].to_dict();return {k:(None if pd.isna(v) else v.item() if hasattr(v,'item') else v) for k,v in z.items()}
 def search_policy(query):return {'results':retrieve(query,3)}
 def calculate_refund(order_amount,delivery_minutes):return {'refund_inr':round(float(order_amount),2) if delivery_minutes is not None and float(delivery_minutes)>45 else 0.0}
 def action(order_id,refund_inr,tool):
  with ledger.open('a') as f:f.write(json.dumps({'timestamp':time.time(),'tool':tool,'order_id':order_id,'refund_inr':refund_inr})+'\n')
  return {'refund_inr':refund_inr}
 def issue_refund(order_id,refund_inr):return action(order_id,refund_inr,'issue_refund')
 def escalate_to_human(order_id,refund_inr):return action(order_id,refund_inr,'escalate_to_human')
 TOOL_MAP={'get_order':get_order,'search_policy':search_policy,'calculate_refund':calculate_refund,'issue_refund':issue_refund,'escalate_to_human':escalate_to_human}
 TOOLS_SPEC=[{'name':n,'description':d,'parameters':p} for n,d,p in [('get_order','Fetch a single order by identifier.',{'order_id':'string'}),('search_policy','Retrieve policy chunks relevant to a query.',{'query':'string'}),('calculate_refund','Calculate refund under the late-delivery policy.',{'order_amount':'number','delivery_minutes':'number'}),('issue_refund','Record an automatically approved refund.',{'order_id':'string','refund_inr':'number'}),('escalate_to_human','Record a refund requiring human approval.',{'order_id':'string','refund_inr':'number'})]]
 Path('outputs/tools_spec.json').write_text(json.dumps(TOOLS_SPEC,indent=2));
 def run_agent(user_message,scenario_id,max_iterations=6,token_limit=6000,time_limit_seconds=10,run_id=None,crash_after=None):
  started=time.monotonic(); messages=[{'role':'system','content':'AGENT Follow tools to decide refund outcomes.'},{'role':'user','content':user_message}];steps=[];tokens=0;llmc=0;tools_done=[]
  for it in range(max_iterations):
   if time.monotonic()-started>=time_limit_seconds:return {'status':'FALLBACK_TIMEOUT','final_answer':'FALLBACK_TIMEOUT: hand off to a human agent.','steps':steps,'llm_calls':llmc,'tokens_used':tokens}
   mock_llm # keep module reference
   try:resp=mock_llm.chat(messages,tools=TOOLS_SPEC)
   except mock_llm.TransientLLMError:continue
   llmc+=1;tokens+=resp.usage.total_tokens
   if tokens>token_limit:return {'status':'FALLBACK_TOKEN_LIMIT','final_answer':'FALLBACK_TOKEN_LIMIT: hand off to a human agent.','steps':steps,'llm_calls':llmc,'tokens_used':tokens}
   msg=resp.choices[0].message; calls=getattr(msg,'tool_calls',[])
   if not calls:
    ans=msg.content or 'FALLBACK: hand off to a human agent.';return {'status':ans.split(':')[0],'final_answer':ans,'steps':steps,'llm_calls':llmc,'tokens_used':tokens}
   call=calls[0]; name=call.name; args=call.arguments if isinstance(call.arguments,dict) else json.loads(call.arguments); messages.append({'role':'assistant','content':None,'tool_calls':[{'id':call.id,'name':name,'arguments':args}]}); obs=TOOL_MAP[name](**args);tools_done.append(name);steps.append({'tool':name,'arguments':args,'observation':obs});messages.append({'role':'tool','tool_call_id':call.id,'name':name,'content':json.dumps(obs)}); checkpoint={'run_id':run_id or scenario_id,'scenario_id':scenario_id,'messages':messages,'tokens_used':tokens,'step_number':len(steps),'tools_executed':tools_done,'steps':steps,'llm_calls':llmc};Path('state/'+str(run_id or scenario_id)+'.json').write_text(json.dumps(checkpoint,indent=2,default=str))
   if crash_after and len(steps)==crash_after:raise RuntimeError('simulated crash after checkpoint')
  return {'status':'FALLBACK_MAX_ITERATIONS','final_answer':'FALLBACK_MAX_ITERATIONS: hand off to a human agent with a summary.','steps':steps,'llm_calls':llmc,'tokens_used':tokens}
 def resume_agent(run_id,max_iterations=6,token_limit=6000,time_limit_seconds=10):
  cp=json.loads(Path('state/'+run_id+'.json').read_text()); messages=cp['messages']; steps=cp.get('steps',[]); tokens=cp['tokens_used']; llmc=cp.get('llm_calls',cp['step_number']); started=time.monotonic(); tools_done=cp['tools_executed']; scenario_id=cp['scenario_id']
  for it in range(llmc,max_iterations):
   if time.monotonic()-started>=time_limit_seconds:return {'status':'FALLBACK_TIMEOUT','final_answer':'FALLBACK_TIMEOUT: hand off to a human agent.','steps':steps,'llm_calls':llmc,'tokens_used':tokens}
   resp=mock_llm.chat(messages,tools=TOOLS_SPEC); llmc+=1; tokens+=resp.usage.total_tokens
   if tokens>token_limit:return {'status':'FALLBACK_TOKEN_LIMIT','final_answer':'FALLBACK_TOKEN_LIMIT: hand off to a human agent.','steps':steps,'llm_calls':llmc,'tokens_used':tokens}
   msg=resp.choices[0].message; calls=getattr(msg,'tool_calls',[])
   if not calls:
    ans=msg.content or 'FALLBACK: hand off to a human agent.';return {'status':ans.split(':')[0],'final_answer':ans,'steps':steps,'llm_calls':llmc,'tokens_used':tokens}
   call=calls[0]; name=call.name; args=call.arguments if isinstance(call.arguments,dict) else json.loads(call.arguments); messages.append({'role':'assistant','content':None,'tool_calls':[{'id':call.id,'name':name,'arguments':args}]}); obs=TOOL_MAP[name](**args);tools_done.append(name);steps.append({'tool':name,'arguments':args,'observation':obs});messages.append({'role':'tool','tool_call_id':call.id,'name':name,'content':json.dumps(obs)}); cp={'run_id':run_id,'scenario_id':scenario_id,'messages':messages,'tokens_used':tokens,'step_number':len(steps),'tools_executed':tools_done,'steps':steps,'llm_calls':llmc};Path('state/'+run_id+'.json').write_text(json.dumps(cp,indent=2,default=str))
  return {'status':'FALLBACK_MAX_ITERATIONS','final_answer':'FALLBACK_MAX_ITERATIONS: hand off to a human agent with a summary.','steps':steps,'llm_calls':llmc,'tokens_used':tokens}
 scenarios=pd.read_csv('data/raw/agent_scenarios.csv',keep_default_na=False); runs=[]
 for _,s in scenarios.iterrows():
  mock_llm.reset();res=run_agent(s.message,s.scenario_id);runs.append({'scenario_id':s.scenario_id,**res});
 Path('outputs/agent_runs.jsonl').write_text('\n'.join(json.dumps(x,default=str) for x in runs)+'\n')
 # demonstrations
 mock_llm.reset(); demo_token=run_agent(scenarios.iloc[0].message,'S1_token_demo',token_limit=200)
 mock_llm.reset(); demo_time=run_agent(scenarios.iloc[0].message,'S1_time_demo',time_limit_seconds=0)
 # Crash after the second tool observation, then resume from the saved checkpoint.
 mock_llm.reset()
 try: run_agent(scenarios.iloc[0].message,'S1_crash_resume',run_id='S1_crash_resume',crash_after=2)
 except RuntimeError: pass
 resumed=resume_agent('S1_crash_resume')
 Path('outputs/resume_demo.json').write_text(json.dumps({'status':resumed['status'],'final_answer':resumed['final_answer'],'tools_executed':[x['tool'] for x in resumed['steps']],'llm_calls':resumed['llm_calls'],'tokens_used':resumed['tokens_used']},indent=2))
 # chunk/retrieval metadata
 Path('outputs/policy_summary.json').write_text(json.dumps({'chunks':len(docs),'top3_refund_query':retrieve('refund policy late delivery',3),'token_demo_status':demo_token['status'],'timeout_demo_status':demo_time['status'],'resume_demo_status':resumed['status'],'scenario_statuses':{x['scenario_id']:x['status'] for x in runs}},indent=2,default=str))
 return runs

def main():
 Path('outputs/retry_log.txt').write_text(''); c,p,o=part_a(); seg=part_b(c,p,o); zero,zt,zc=triage('zero',100000,seg,'outputs/triage_zero_shot.csv'); few,ft,fc=triage('few',100000,seg,'outputs/triage_results.csv'); bud,bt,bc=triage('zero',6000,seg,'outputs/triage_budget_demo.csv'); eligible=few[few.status.isin(['classified_json','classified_keyword'])]; print('Part C zero accuracy',accuracy_score(zero[zero.status.isin(['classified_json','classified_keyword'])].true_category,zero[zero.status.isin(['classified_json','classified_keyword'])].category),'tokens',zt,'few accuracy',accuracy_score(eligible.true_category,eligible.category),'tokens',ft,'budget_exhausted',int((bud.status=='budget_exhausted').sum()),'redactions',zc); runs=part_d();print('Pipeline complete. Outputs are in outputs/.')
if __name__=='__main__':main()
