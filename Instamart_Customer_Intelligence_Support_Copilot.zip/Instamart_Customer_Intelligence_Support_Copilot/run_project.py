"""Convenience entry point: regenerate all project outputs and reports."""
import subprocess, sys
for script in ('generate_data.py','run_all.py','reporting.py','validate_project.py'):
    subprocess.run([sys.executable, script], check=True)
