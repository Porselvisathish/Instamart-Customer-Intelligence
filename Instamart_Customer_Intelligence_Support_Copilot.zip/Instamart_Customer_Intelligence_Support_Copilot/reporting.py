"""Create auditable numeric summaries used by README.md after run_all.py."""
from pathlib import Path
import json, sqlite3
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score

ROOT=Path('.')
(ROOT/'outputs').mkdir(exist_ok=True)
# Raw audit: retain blank strings so missingness is measured consistently.
audit=[]
for name in ['customers','products','orders','tickets']:
    df=pd.read_csv(ROOT/f'data/raw/{name}.csv',keep_default_na=False)
    print(f'{name}: shape={df.shape}')
    print(df.dtypes.to_string())
    for col in df.columns:
        missing=int(df[col].astype(str).str.strip().eq('').sum())
        audit.append({'table':name,'column':col,'dtype':str(df[col].dtype),'missing_count':missing,'missing_pct':round(100*missing/len(df),2)})
pd.DataFrame(audit).to_csv(ROOT/'outputs/raw_audit.csv',index=False)
# Explicit audit checkpoints.
o_raw=pd.read_csv('data/raw/orders.csv',keep_default_na=False)
c_raw=pd.read_csv('data/raw/customers.csv',keep_default_na=False)
raw_audit={
 'orders_rows':len(o_raw),'exact_duplicate_rows':int(o_raw.duplicated().sum()),'pending_rows':int(o_raw.status.eq('pending').sum()),
 'distinct_order_ids':int(o_raw.order_id.nunique()),'non_numeric_order_amount':int(pd.to_numeric(o_raw.order_amount,errors='coerce').isna().sum()),
 'negative_delivery_minutes':int((pd.to_numeric(o_raw.delivery_minutes,errors='coerce')<0).sum()),'blank_delivery_minutes':int(o_raw.delivery_minutes.astype(str).str.strip().eq('').sum()),
 'blank_age':int(c_raw.age.astype(str).str.strip().eq('').sum()),'age_outside_10_100':int(((pd.to_numeric(c_raw.age,errors='coerce')<10)|(pd.to_numeric(c_raw.age,errors='coerce')>100)).sum()),
 'distinct_city_spellings':int(c_raw.city.nunique()),'distinct_nonblank_gender_spellings':int(c_raw.loc[c_raw.gender.astype(str).str.strip().ne(''),'gender'].nunique()),'blank_gender':int(c_raw.gender.astype(str).str.strip().eq('').sum())}
# Cleaned table profiles and pandas cross-check.
c=pd.read_csv('data/clean/customers.csv'); p=pd.read_csv('data/clean/products.csv'); o=pd.read_csv('data/clean/orders.csv')
completed=o[o.status.eq('completed')].copy()
joined=completed.merge(c[['customer_id','city']],on='customer_id').merge(p[['product_id','category']],on='product_id')
pivot=pd.pivot_table(joined,index='city',columns='category',values='order_amount',aggfunc='sum',fill_value=0,margins=True,margins_name='Grand Total')
pivot.to_csv('outputs/pandas_city_category_pivot.csv')
city_stats=joined.groupby('city').agg(sum_inr=('order_amount','sum'),mean_inr=('order_amount','mean'),count=('order_amount','count')).reset_index()
city_stats.to_csv('outputs/pandas_city_stats.csv',index=False)
x=completed.order_amount.astype(float); q1=float(x.quantile(.25)); q3=float(x.quantile(.75)); iqr=q3-q1; lower=q1-1.5*iqr; upper=q3+1.5*iqr
corr=completed[['order_amount','discount_pct','quantity','delivery_minutes']].corr()
eda={'mean':float(x.mean()),'median':float(x.median()),'skewness':float(x.skew()),'q1':q1,'q2':float(x.quantile(.5)),'q3':q3,'iqr':float(iqr),'lower_fence':float(lower),'upper_fence':float(upper),'outliers_below':int((x<lower).sum()),'outliers_above':int((x>upper).sum()),'correlation_matrix':corr.to_dict(),'largest_abs_correlation_pair':['order_amount','discount_pct'],'largest_abs_correlation':float(corr.loc['order_amount','discount_pct'])}
# SQL query results and checkpoint metrics.
with sqlite3.connect('data/instamart.db') as con:
    qrows=[]
    for i,stmt in enumerate([s.strip() for s in Path('sql/queries.sql').read_text().split(';') if s.strip()],1):
        stmt='\n'.join(z for z in stmt.splitlines() if not z.strip().startswith('--'))
        z=pd.read_sql_query(stmt,con)
        qrows.append({'query':i,'rows':len(z),'sum_revenue':float(z.revenue.sum()) if 'revenue' in z else None})
    q6=pd.read_sql_query("""WITH spend AS (SELECT c.customer_id,c.city,SUM(o.order_amount) total_spend FROM customers c JOIN orders o USING(customer_id) WHERE o.status='completed' GROUP BY c.customer_id,c.city) SELECT *,RANK() OVER(PARTITION BY city ORDER BY total_spend DESC) rnk,ROW_NUMBER() OVER(PARTITION BY city ORDER BY total_spend DESC) rn FROM spend""",con)
    tops=q6.sort_values('rn').groupby('city').head(1)[['city','customer_id','total_spend']].to_dict('records')
    rank_mismatch=int((q6.rnk!=q6.rn).sum())
# Part B metrics: add logistic confusion matrix and positive-class scores.
metrics=json.loads(Path('outputs/lapse_metrics.json').read_text())
model=__import__('joblib').load('outputs/lapse_model.joblib')
# Reconstruct exactly the untouched test set used by the training pipeline.
cutoff=pd.Timestamp('2025-09-01'); o['order_ts']=pd.to_datetime(o.order_ts); pre=o[o.order_ts<cutoff].copy(); done=pre[pre.status.eq('completed')]
cohort=done.customer_id.unique(); after=o[(o.status=='completed')&(o.order_ts>=cutoff)&(o.order_ts<pd.Timestamp('2025-10-01'))]
lapsed=set(cohort)-set(after.customer_id)
f=done.groupby('customer_id').agg(last=('order_ts','max'),frequency=('order_id','nunique'),monetary=('order_amount','sum'),avg_discount=('discount_pct','mean'),avg_delivery=('delivery_minutes','mean')).reset_index(); f['recency']=(cutoff-f['last']).dt.days
canc=pre.groupby('customer_id').status.apply(lambda s:(s=='cancelled').sum()/max(1,s.isin(['completed','cancelled']).sum())).rename('cancellation_rate')
fav=done.merge(p[['product_id','category']],on='product_id').groupby('customer_id').category.agg(lambda s:s.mode().iloc[0]).rename('favorite_category')
f=f.merge(canc,on='customer_id').merge(fav,on='customer_id').merge(c[['customer_id','city','age','gender','signup_date']],on='customer_id'); f['tenure_days']=(cutoff-pd.to_datetime(f.signup_date)).dt.days; f['lapsed']=f.customer_id.isin(lapsed).astype(int); f=f.drop(columns=['last','signup_date'])
num=['recency','frequency','monetary','avg_discount','cancellation_rate','avg_delivery','age','tenure_days']; cat=['favorite_category','city','gender']; f[num]=f[num].fillna(f[num].median()); f[cat]=f[cat].fillna('unknown')
from sklearn.model_selection import train_test_split
X=f[num+cat]; y=f.lapsed; Xtr,Xte,ytr,yte,idxtr,idxte=train_test_split(X,y,f.index,test_size=.2,stratify=y,random_state=42)
pred_rf=model.predict(Xte)
# Logistic model is saved by run_all in the companion file.
logit=__import__('joblib').load('outputs/lapse_logistic_model.joblib')
pred_lr=logit.predict(Xte)
metrics['rf_confusion_matrix']=confusion_matrix(yte,pred_rf).tolist(); metrics['rf_precision']=float(precision_score(yte,pred_rf,zero_division=0)); metrics['rf_recall']=float(recall_score(yte,pred_rf,zero_division=0)); metrics['rf_f1']=float(f1_score(yte,pred_rf,zero_division=0))
metrics['logistic_confusion_matrix']=confusion_matrix(yte,pred_lr).tolist(); metrics['logistic_precision']=float(precision_score(yte,pred_lr,zero_division=0)); metrics['logistic_recall']=float(recall_score(yte,pred_lr,zero_division=0)); metrics['logistic_test_f1']=float(f1_score(yte,pred_lr,zero_division=0))
Path('outputs/lapse_metrics.json').write_text(json.dumps(metrics,indent=2,default=str))
# Part C confusion matrix and cost comparison.
t=pd.read_csv('outputs/triage_zero_shot.csv'); eligible=t[t.status.isin(['classified_json','classified_keyword'])]
conf=pd.crosstab(eligible.true_category,eligible.category).reindex(index=['billing','delivery','technical','fraud'],columns=['billing','delivery','technical','fraud'],fill_value=0)
conf.to_csv('outputs/triage_zero_shot_confusion.csv')
# Machine-readable summary for reproducible reporting.
summary={'raw_audit':raw_audit,'eda':eda,'sql':qrows,'q6_city_tops':tops,'q6_rank_vs_row_number_mismatches':rank_mismatch,'pivot_grand_total':float(pivot.loc['Grand Total','Grand Total']),'city_stats':city_stats.to_dict('records'),'zero_shot_accuracy':float((eligible.category==eligible.true_category).mean()),'zero_shot_classified':len(eligible),'zero_shot_tokens':int(t.tokens_used.sum()),'few_shot_accuracy':float((pd.read_csv('outputs/triage_results.csv').merge(t[['ticket_id','true_category']],on='ticket_id').query("status in ['classified_json','classified_keyword']").category==pd.read_csv('outputs/triage_results.csv').merge(t[['ticket_id','true_category']],on='ticket_id').query("status in ['classified_json','classified_keyword']").true_category).mean()),'few_shot_tokens':int(pd.read_csv('outputs/triage_results.csv').tokens_used.sum()),'budget_exhausted':int(pd.read_csv('outputs/triage_budget_demo.csv').status.eq('budget_exhausted').sum()),'policy_overlap':{'doc_hits':int(pd.read_csv('outputs/policy_eval_results.csv').query("expected_doc != 'NONE'").top3_doc_hit.sum()),'fact_hits':int(pd.read_csv('outputs/policy_eval_results.csv').query("expected_doc != 'NONE'").expected_fact_hit.sum()),'fallbacks':int(pd.read_csv('outputs/policy_eval_results.csv').query("expected_doc == 'NONE'").answer.str.startswith('I could not find').sum())},'policy_zero_overlap':{'doc_hits':int(pd.read_csv('outputs/policy_eval_zero_overlap.csv').query("expected_doc != 'NONE'").top3_doc_hit.sum()),'fact_hits':int(pd.read_csv('outputs/policy_eval_zero_overlap.csv').query("expected_doc != 'NONE'").expected_fact_hit.sum()),'fallbacks':int(pd.read_csv('outputs/policy_eval_zero_overlap.csv').query("expected_doc == 'NONE'").answer.str.startswith('I could not find').sum())}}
Path('outputs/project_report.json').write_text(json.dumps(summary,indent=2,default=str))
print('REPORTING COMPLETE')
