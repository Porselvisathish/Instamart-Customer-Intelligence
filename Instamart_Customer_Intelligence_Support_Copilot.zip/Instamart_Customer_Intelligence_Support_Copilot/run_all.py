"""Root entry point retained for the documented reproduction workflow."""
from src.pipeline import main

if __name__ == '__main__':
    main()
