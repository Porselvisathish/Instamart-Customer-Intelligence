"""Source package for the Instamart Copilot pipeline."""
