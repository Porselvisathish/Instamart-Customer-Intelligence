# Notebook policy

The graded deliverable is a reproducible text-and-code repository. All analyses and model runs are implemented as executable Python scripts and their numeric findings are documented in the root `README.md`; no chart or screenshot artifacts are required. This folder is reserved for optional future exploratory notebooks, and intentionally contains no notebook output files.
