# Upload this project to GitHub

1. Extract `Instamart_Customer_Intelligence_Support_Copilot.zip`.
2. Open a terminal in the extracted `Instamart_Customer_Intelligence_Support_Copilot` folder.
3. Create a new **public** GitHub repository. Do not initialise it with an extra README or license because this folder already contains the project README.
4. Run:

```bash
git init -b main
git add .
git commit -m "Submit Instamart Customer Intelligence and Support Copilot"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

5. Replace the example remote URL with the repository URL from GitHub. Confirm the repository visibility is Public and the active branch is `main`.
6. Submit this form of link: `https://github.com/YOUR_USERNAME/YOUR_REPOSITORY/tree/main`.

Do not upload `.venv/`, `.env`, API keys, screenshots, charts or other non-required media. The `.gitignore` already excludes the local environment and common Python cache files.
