"""Reference-check validation for the cleaned Part A tables and database."""
import sqlite3
import pandas as pd

c=pd.read_csv('data/clean/customers.csv')
o=pd.read_csv('data/clean/orders.csv')
assert len(c)==1200
assert c.city.nunique()==6
assert c.age.notna().all()
assert c.gender.value_counts().to_dict()=={'female':610,'male':560,'unknown':30}
assert len(o)==12309
assert o.order_id.nunique()==12309
assert int((o.status=='completed').sum())==11110
assert int((o.status=='cancelled').sum())==1199
assert not (o.status=='pending').any()
assert pd.to_numeric(o.order_amount,errors='coerce').notna().all()
assert o.loc[o.status=='completed','delivery_minutes'].notna().all()
assert o.loc[o.status=='cancelled','delivery_minutes'].isna().all()
assert round(o.loc[o.status=='completed','order_amount'].sum(),2)==2998668.80
with sqlite3.connect('data/instamart.db') as con:
    tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
assert {'customers','products','orders'} <= tables
print('ALL CHECKPOINTS PASSED')
