# Useful official references

- Python virtual environments: https://docs.python.org/3/library/venv.html
- Python `sqlite3`: https://docs.python.org/3/library/sqlite3.html
- pandas user guide: https://pandas.pydata.org/docs/user_guide/index.html
- scikit-learn user guide: https://scikit-learn.org/stable/user_guide.html
- scikit-learn model persistence: https://scikit-learn.org/stable/model_persistence.html
- SQLite window functions: https://www.sqlite.org/windowfunctions.html
- GitHub: create a repository: https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository
- GitHub: pushing local code: https://docs.github.com/en/get-started/using-git/pushing-commits-to-a-remote-repository

The capstone itself runs offline and does not require any hosted service or account-gated API.
