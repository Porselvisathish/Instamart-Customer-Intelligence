# Instamart Customer Intelligence & Support Copilot

## Overview

This repository implements the four-part, fully offline synthetic capstone: (A) data quality, cleaning, SQLite and SQL analysis; (B) RFM customer segmentation and leakage-controlled lapse prediction; (C) privacy-first support-ticket classification and routing; and (D) TF-IDF policy retrieval, grounded policy answers and a tool-using refund agent. All data is synthetic and fictional. Monetary values are INR. No network service, API key, paid service or hosted language model is used; every language-model call goes through the local `mock_llm.py`.

The project is designed for Python 3.11+ and SQLite 3.25+. The source files `generate_data.py` and `mock_llm.py` are included at the repository root. The run order is deterministic and the scripts recreate the committed output files.

## Reproduce

Run these commands from the repository root. On Windows, activate the environment with `.venv\\Scripts\\activate`; on macOS/Linux use `source .venv/bin/activate`.

1. `python -m venv .venv`
2. `source .venv/bin/activate`
3. `python -m pip install --upgrade pip`
4. `pip install -r requirements.txt`
5. `python generate_data.py`
6. `python run_all.py`
7. `python reporting.py`
8. `python validate_project.py`

The last line of step 5 is `generated: customers=1200 products=40 orders_raw=13084 tickets=164`. Step 6 creates the cleaned CSVs, SQLite database, segmentation/model artifacts, triage outputs, policy evaluation, agent runs and checkpoints. Step 7 writes the audit and numeric report files. Step 8 independently asserts the Part A checkpoints and prints `ALL CHECKPOINTS PASSED`. `python run_project.py` is a convenience command that runs all four scripts in the same order.

Expected key completion messages include `ALL CHECKPOINTS PASSED` and `REPORTING COMPLETE`. The repository's `.gitignore` excludes `.env`, `.venv/`, `venv/`, `__pycache__/`, bytecode and local database journals. Do not commit secrets or replace the offline model with a network call.

## Part A

### Raw audit

All four raw CSVs were loaded with pandas; `tickets.csv` uses `keep_default_na=False` so blank ticket text remains an empty string. The audit file `outputs/raw_audit.csv` contains each column's pandas dtype, missing count and missing percentage. Shapes and non-zero missingness are summarised below (all columns not listed as missing have 0 missing values).

| Raw table | Shape | Column dtypes | Missing / blank values |
|---|---:|---|---|
| customers.csv | 1,200 × 5 | all `object` | age 61 (5.08%); gender 30 (2.50%) |
| products.csv | 40 × 4 | product_id/product_name/category `object`; price_inr `int64` | none |
| orders.csv | 13,084 × 9 | order_id/customer_id/product_id/order_ts/status/order_amount/delivery_minutes `object`; quantity/discount_pct `int64` | delivery_minutes 2,541 (19.42%); blank values in other columns 0 |
| tickets.csv | 164 × 5 | all `object` | order_id 8 (4.88%); text 4 (2.44%) |

| Raw audit checkpoint | Count |
|---|---:|
| Order rows | 13,084 |
| Exact duplicate order rows | 119 |
| Pending order rows | 656 |
| Distinct order_id | 12,309 |
| Non-numeric order_amount entries | 120 |
| Negative delivery_minutes | 106 |
| Blank delivery_minutes | 2,541 |
| Blank customer ages | 61 |
| Ages outside 10–100 | 6 |
| Distinct raw city spellings | 24 |
| Distinct non-blank raw gender spellings | 10 |
| Blank gender | 30 |

### Cleaning rules and validation

- **Customers:** city values were stripped and title-cased, reducing 24 raw spellings to the six canonical cities. Gender variants were mapped to `male`, `female` or `unknown`; all 30 blanks became `unknown`. Ages outside 10–100 (6 rows) and blank ages (61 rows) were set missing, then all 67 missing ages were filled with the city median using `groupby('city').transform('median')`. `signup_date` was converted to datetime and written back as ISO date text. The resulting city counts are Pune 227, Delhi 210, Bengaluru 197, Chennai 191, Hyderabad 191 and Mumbai 184; genders are female 610, male 560 and unknown 30. There are no missing ages; all cleaned ages are 18–60.
- **Orders:** `order_ts` was parsed as datetime; 119 exact duplicate rows were removed; rows were sorted by timestamp and the latest record retained per order_id, which removes the 656 earlier pending records. This leaves 12,309 unique orders: 11,110 completed and 1,199 cancelled, with no pending rows. The 120 unparseable amounts were converted to missing and imputed using rounded catalogue price × quantity × (1 − discount percentage / 100), leaving no missing order amount. All 106 negative delivery durations were set missing. Of the remaining latest completed orders, 774 missing delivery durations were filled with the completed-order median for that product category; cancelled orders retain missing delivery time because they were never delivered. Final missing delivery times: 0 completed, 1,199 cancelled. Completed-order revenue is INR 2,998,668.80.
- **Storage:** the clean customers, products and orders are saved under `data/clean/` and loaded into `data/instamart.db` as `customers`, `products` and `orders`. `order_ts` is stored as `YYYY-MM-DD HH:MM:SS` text. The Part A assertions cover more than eight reference checks and print `ALL CHECKPOINTS PASSED` only when they all hold.

### SQL analysis

All seven statements are saved in `sql/queries.sql` and executed with `pandas.read_sql_query` against the SQLite database.

| Query | Result |
|---|---|
| Q1 WHERE + HAVING | 30 customers have completed-order totals over INR 8,000 from orders individually above INR 500. |
| Q2 three-table join | 30 city/category rows; revenue totals INR 2,998,668.80. Largest cell: Bengaluru / Electronics, INR 233,909.45. |
| Q3 scalar subquery | 11 products priced above the catalogue average. |
| Q4 LEFT JOIN | 25 customers have no completed order. |
| Q5 CTE | 550 customers spend above the average customer total; average completed spend is INR 2,552.06. |
| Q6 ranking windows | Top spenders: Bengaluru C0082 (INR 12,856.20); Chennai C0930 (INR 10,151.40); Delhi C0291 (INR 13,742.60); Hyderabad C0743 (INR 12,730.05); Mumbai C0693 (INR 14,766.55); Pune C0426 (INR 10,377.10). There are 8 rows where RANK differs from ROW_NUMBER because tied spend values share a rank, while ROW_NUMBER still assigns a unique sequential position. |
| Q7 running total | 183 daily revenue rows; final cumulative revenue INR 2,998,668.80. |

### pandas cross-check and exploratory analysis

`outputs/pandas_city_category_pivot.csv` is a `pivot_table(..., margins=True)` cross-check; its grand total is INR 2,998,668.80, matching SQL Q2. City-level completed-order aggregates are saved in `outputs/pandas_city_stats.csv`.

| City | Completed revenue (INR) | Mean order (INR) | Orders |
|---|---:|---:|---:|
| Bengaluru | 523,643.40 | 276.47 | 1,894 |
| Chennai | 463,629.15 | 272.72 | 1,700 |
| Delhi | 502,829.80 | 243.62 | 2,064 |
| Hyderabad | 528,589.90 | 284.95 | 1,855 |
| Mumbai | 479,058.50 | 297.00 | 1,613 |
| Pune | 500,918.05 | 252.48 | 1,984 |

Completed-order amount statistics: mean INR 269.91; median INR 135.00; skewness 4.61; Q1 INR 64.80; Q3 INR 297.00; IQR INR 232.20; lower fence −INR 283.50; upper fence INR 645.30; 0 observations below the lower fence and 897 above the upper fence. The order amount distribution is strongly right-skewed: the median is much lower than the mean because a relatively small number of high-value baskets pull the mean upward. Those 897 upper-tail values are statistical outliers under the 1.5×IQR rule, not automatically data errors; the synthetic dataset includes premium electronics baskets. The largest absolute correlation is order_amount with discount_pct (−0.095); order_amount with quantity is +0.087. These are both weak associations, and a correlation of this size does not establish causation.

## Part B

### RFM and clustering

RFM is calculated for completed orders as of 2025-10-01 00:00:00. The table contains 1,175 customers; recency median 19 days (minimum 0, maximum 180), frequency mean 9.46 (maximum 33), and monetary mean INR 2,552.06 (maximum INR 14,766.55). The scaled RFM K-means comparison is:

| K | Inertia | Silhouette |
|---:|---:|---:|
| 2 | 1,820.8 | 0.465 |
| 3 | 1,268.2 | 0.445 |
| 4 | 743.1 | 0.526 |
| 5 | 617.4 | 0.481 |
| 6 | 503.2 | 0.482 |
| 7 | 408.5 | 0.416 |
| 8 | 366.5 | 0.412 |

K=4 is selected: it has the best silhouette of the tested values, a clear inertia reduction from K=3, and yields four actionable groups. Inertia always decreases as K increases because more centroids can fit the training points more closely; K=8 therefore has lower inertia than K=2 by construction, but this does not account for model complexity or whether the extra clusters are meaningful to the business.

| Segment ID | Name | Size | Mean recency (days) | Mean frequency | Mean monetary (INR) | Recommended action |
|---:|---|---:|---:|---:|---:|---|
| 0 | Occasional Value | 436 | 28.86 | 3.77 | 1,057.62 | Use low-cost replenishment reminders and category bundles. |
| 1 | Premium | 138 | 24.12 | 6.77 | 7,129.70 | Offer priority support and tailored high-value cross-sells. |
| 2 | Frequent Essentials | 419 | 8.77 | 19.40 | 3,410.02 | Protect habit with subscription-like replenishment and loyalty benefits. |
| 3 | Dormant / At-Risk | 182 | 109.04 | 2.20 | 685.99 | Trigger win-back messaging and a time-limited return incentive. |

Segment 1 is Premium because it has the highest mean monetary value. Cluster IDs are arbitrary labels, not an ordinal ranking. PCA on the scaled RFM matrix explains 0.634 and 0.218 of variance (total 0.852). Segment assignments are in `outputs/customer_segments.csv` with the required columns.

### Lapse prediction

The cohort includes every customer with a completed order before 2025-09-01: 1,156 customers, of whom 443 (38.32%) lapsed during 2025-09-01 through 2025-09-30. The stratified split is 924 training rows and 232 test rows. Features use only pre-cutoff completed/final-status orders and the clean customer table: recency, frequency, monetary, average discount, cancellation rate, average delivery time, favourite product category, city, age, gender and tenure. No order dated 2025-09-01 or later entered the features, and Part B segment labels were not used as features. The feature matrix is asserted to contain no missing values. The categorical encoder and numeric scaler are in a training-fitted scikit-learn pipeline; no encoder, scaler or resampler saw test rows. The training scaler's learned frequency mean is 8.115 versus the full-cohort mean 8.029 because the scaler is fitted on the training partition only, not on the held-out test customers.

The always-not-lapsed baseline has 61.6% test accuracy and lapsed-class F1 of 0. Grid searches use LogisticRegression(max_iter=1000), C ∈ {0.01, 0.1, 1, 10, 100}, and RandomForestClassifier(n_estimators=100, random_state=42), max_depth ∈ {3, 5, 8}, min_samples_leaf ∈ {5, 10, 20}, each with 5-fold CV and positive-class F1 scoring.

| Model | Best parameters | Best CV F1 | Test confusion matrix (actual rows: 0,1; predicted columns: 0,1) | Lapsed precision | Lapsed recall | Lapsed F1 |
|---|---|---:|---|---:|---:|---:|
| Logistic regression | C=100 | 0.651 | [[111, 32], [31, 58]] | 0.644 | 0.652 | 0.648 |
| Random forest | depth=8, min_samples_leaf=10 | 0.687 | [[111, 32], [32, 57]] | 0.640 | 0.640 | 0.640 |

The random forest is persisted as `outputs/lapse_model.joblib` and is selected because it has the stronger cross-validated F1 and captures nonlinear feature interactions; its untouched-test lapsed F1 is 0.640, above the required 0.55. Logistic regression is a close comparator and has a slightly higher test F1 on this one split, so the model choice should be monitored on later cohorts. Missing a genuinely lapsing customer means losing future orders and lifetime value; wrongly targeting a loyal customer wastes an incentive and may train them to wait for discounts. For retention, the recall/precision trade-off should be set against campaign capacity and offer cost rather than accuracy alone. Reloading the saved model reproduces its original test predictions exactly.

The top random-forest importances are monetary (0.278), frequency (0.277), recency (0.111), average delivery (0.062) and average discount (0.053). Three logistic coefficient readings: frequency is negative (−1.698), so more frequent ordering lowers predicted lapse odds; the Electronics favourite-category indicator is negative (−1.137) relative to the dropped reference category; monetary is positive (+0.285) conditional on the other features in this fitted model. These are model associations, not causal effects.

The training-only random oversampling experiment duplicates lapsed training rows to balance both classes at 570 each. On the unchanged test set, logistic regression moves from precision 0.644, recall 0.652, F1 0.648 to precision 0.589, recall 0.854, F1 0.697. Recall moves most (+0.202), meaning more potential lapsers are caught, at the cost of more loyal customers being targeted. The selected RF model and its reload check are in `outputs/lapse_model.joblib`; the illustrative Premium retention shortlist is `outputs/retention_list.csv` and contains 10 customers, of whom 1 actually lapsed. The Premium flag comes from whole-window RFM including September, so the retention list is illustrative and is not a leakage-free evaluation.

## Part C

### Guardrails, privacy and reliability

The 164 tickets are processed in file order. Four empty/whitespace tickets are marked `skipped_empty`; four tickets above `MAX_INPUT_TOKENS=400` are marked `flagged_long` (734 estimated tokens each). Neither group is sent to the model. Before any prompt is assembled, the text is redacted in this order: email → `[EMAIL]`, phone → `[PHONE]`, order id → `[ORDER_ID]`. Substitutions across the complete file: 55 emails, 91 phone numbers and 132 order IDs (278 total). A second regex pass finds zero residual email, phone or order-ID patterns. The user message content is exactly the redacted ticket text, with no wrapper text. Code asserts the redacted prompt contains none of the three PII patterns.

Both zero-shot and few-shot system prompts contain `CLASSIFY`, the four allowed categories (billing, delivery, technical, fraud), and require JSON-only `{"category": "...", "reason": "..."}` output. The zero-shot prompt has no `EXAMPLES:` line; the few-shot prompt includes labelled fraud and delivery examples. Every model call is protected by a maximum of three retries after the initial attempt, exponential backoff `0.05 × 2**n` and jitter `uniform(0.9, 1.15)`. Each retry is logged with ticket ID, retry number and wait. Each full run resets `mock_llm`; the 156 eligible tickets generate 19 transient errors per run, all recovered. The console lines are persisted in `outputs/retry_log.txt`; separate run logs are `outputs/retry_log_zero_shot.txt` and `outputs/retry_log_few_shot.txt` (19 lines each) and `outputs/retry_log_budget_demo.txt` (15 recovered failures before the budget stopped further calls).

The response validator accepts an allowed category in JSON as `classified_json`; otherwise it extracts lowercase words with `re.findall(r'[a-z]+', text.lower())` and accepts exactly one allowed category as `classified_keyword`. All other responses, including valid JSON with category `shipping`, are `flagged_invalid_output` and sent to human review without guessing. Per full run: 135 `classified_json`, 12 `classified_keyword`, 9 `flagged_invalid_output`, 4 `flagged_long`, 4 `skipped_empty`.

### Prompt comparison and budget

Both prompt runs classify 147 tickets. Zero-shot accuracy is 85.7% (126/147), with 7,528 total tokens or 51.21 tokens per classified ticket. Few-shot accuracy is 100% (147/147), with 10,024 tokens or 68.19 tokens per classified ticket. The additional 2,496 tokens (16.98 per classified ticket) buy a 14.3 percentage-point accuracy improvement, so few-shot is worthwhile when a misrouted fraud or technical ticket is more costly than the extra offline token budget. The zero-shot confusion table is:

| True \\ Predicted | billing | delivery | technical | fraud |
|---|---:|---:|---:|---:|
| billing | 38 | 0 | 0 | 0 |
| delivery | 0 | 36 | 0 | 0 |
| technical | 10 | 0 | 29 | 0 |
| fraud | 11 | 0 | 0 | 23 |

The zero-shot run's 21 misclassifications are fraud→billing (11) and technical→billing (10). The zero-shot budget demonstration uses TOKEN_BUDGET=6,000 and has 31 `budget_exhausted` tickets; the final call may take the running total slightly over budget because the rule checks the total before the next call.

The final `outputs/triage_results.csv` is the few-shot run with TOKEN_BUDGET=100,000 and has all 164 rows. `skipped_empty`, `flagged_long`, `flagged_invalid_output` and `budget_exhausted` route to `human_review` at NORMAL priority; valid fraud routes to `security_team` at HIGH; other valid tickets from Premium customers route to `premium_desk` at HIGH; remaining valid tickets route to `support_queue` at NORMAL. Customers missing from the segment file are treated as non-premium. `outputs/triage_budget_demo.csv` contains the budget-stop demonstration. Rule-validated model outputs are those with `classified_json` or `classified_keyword`; all invalid, empty, long or exhausted cases go to human review.

## Part D

### Policy retrieval and grounded answers

The five policy files are split into 40-word chunks with 10-word overlap, preserving the source filename. There are 15 chunks: refund 4, delivery 3, escalation 3, payment 3 and privacy 2. A default `TfidfVectorizer()` is fitted on chunk text; query vectors are ranked with cosine similarity. For `refund policy late delivery`, the top three chunks all come from `refund_policy.txt`. TF measures how often a term appears in a chunk; IDF gives more weight to terms that are rare across the chunk collection. TF-IDF can miss semantically equivalent phrasings when the question and policy use different words.

The policy assistant sends a system instruction containing `POLICY ASSISTANT` and a user message exactly formatted as `CONTEXT:` + three `[source] chunk` lines + `QUESTION:` + question. It answers only from retrieved context and falls back when no relevant fact is found. On the 12 answerable evaluation questions, overlapping chunks retrieve the expected document for 12/12 and include the expected fact in 12/12 answers; both unanswerable questions receive the `I could not find` fallback (2/2). With zero overlap, the expected document remains in the top three for 12/12 but only 10/12 answers contain the expected fact. Two broken questions are “What delivery time makes a completed order eligible for a full refund?” and “How soon is money returned when a payment fails but is deducted?” In each case the key fact is split at a 40-word chunk boundary, so retrieval finds the correct policy document but the model's selected sentence lacks the complete answer.

### Refund tools and ReAct results

Five tools are implemented and mapped by name in `TOOL_MAP`: `get_order`, `search_policy`, `calculate_refund`, `issue_refund` and `escalate_to_human`; their descriptions and JSON-style parameter specifications are saved in `outputs/tools_spec.json`. `get_order` queries the Part A SQLite database; `search_policy` calls the same retrieval function; `calculate_refund` returns the full order amount only for completed orders delivered in more than 45 minutes; completed orders at or below 45 minutes receive zero; amounts above INR 1,000 are escalated and not issued automatically. Issue/escalation tools append timestamped JSON lines to `outputs/refund_ledger.jsonl`.

| Scenario | Status | Refund amount (INR) | Model calls | Tokens |
|---|---|---:|---:|---:|
| S1 | REFUND | 128.25 | 5 | 882 |
| S2 | REFUND | 135.00 | 5 | 882 |
| S3 | ESCALATE | 1,999.00 | 5 | 869 |
| S4 | DENIED | 0.00 | 4 | 593 |
| S5 | DENIED | 0.00 | 3 | 328 |
| S6 | NOT_FOUND | 0.00 | 2 | 66 |
| S7 | FALLBACK_MAX_ITERATIONS | 0.00 | 6 | 2,982 |

S1–S6 match the seven scenario outcomes and expected amounts; S7 intentionally loops until the six-call iteration cap. With default token_limit=6,000 it completes all six calls and stops with `FALLBACK_MAX_ITERATIONS`. The S1 demonstration with token_limit=200 ends `FALLBACK_TOKEN_LIMIT`; the S1 demonstration with time_limit_seconds=0 ends `FALLBACK_TIMEOUT` before the first model call. Each fallback includes completed steps and a human-handoff summary.

### Crash recovery and design comparison

After every tool observation, the agent writes a checkpoint under `state/` with run ID, scenario ID, full messages, tokens used, step number and executed tools. In the S1 simulated crash, the checkpoint is written immediately after the second tool execution. Resuming that run executes the tools in this exact order across both segments: `get_order` → `search_policy` → `calculate_refund` → `issue_refund`. No tool is repeated; the resumed final status is REFUND for INR 128.25. The complete run records are in `outputs/agent_runs.jsonl`, and the resumed-run summary is in `outputs/resume_demo.json`.

ReAct makes a model call after each observation: S1 needs 5 calls, S5 3 and S6 2, so token use grows with the interaction and the agent can react to a missing order or cancelled status before issuing a refund. A plan-and-execute design could ask for the whole tool sequence once and use fewer calls/tokens on the happy path, but a NOT_FOUND or cancelled-order observation would require validating and replanning rather than blindly executing the remaining plan. For this refund workflow I choose ReAct because the order lookup and policy checks are safety gates, and an extra model call is preferable to executing a stale or unsafe refund plan.

## Limitations and Next Steps

This is a deterministic synthetic demonstration, not production customer or policy data. TF-IDF is lexical rather than semantic; production retrieval would need stronger evaluation and policy versioning. The classifier is a keyword-driven offline mock, not a trained language model. The lapse model is trained on a single synthetic time window and should be monitored for drift, calibration and segment-level fairness before operational use. Refund ledger actions are simulated local writes, not real payment operations. The Premium flag used to create the retention shortlist is derived from whole-window RFM including September, which overlaps the lapse-label period; therefore the retention list is illustrative and is not a leakage-free evaluation. Next steps would include temporal backtesting on later windows, calibrated thresholds tied to campaign capacity, human review sampling, audit retention and policy-owner approval before any production integration.
